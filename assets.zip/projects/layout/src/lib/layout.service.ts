import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class LayoutService {

  constructor() { 
    console.log('111');

  }

  getData(){
    console.log('333');
  }
}
