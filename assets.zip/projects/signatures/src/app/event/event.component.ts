import {AfterViewInit, Component, ViewChild, Inject} from '@angular/core';
import {MatDialog, MAT_DIALOG_DATA} from '@angular/material/dialog';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';
import {RestApiService} from '../api.service';
import {ActivatedRoute} from '@angular/router';
import {Title} from '@angular/platform-browser';
import {Router} from '@angular/router';
import {MatSnackBar} from '@angular/material/snack-bar';

@Component({
  selector: 'app-event',
  templateUrl: './event.component.html',
  styleUrls: ['./event.component.scss']
})
export class EventComponent implements AfterViewInit {
  displayedColumns: string[] = ['name', 'reorder', 'order', 'code', 'actions'];
  dataSource = new MatTableDataSource();
  public url_id;
  public url_gorem;
  public goremSelect: string;
  public goremList:any;
  public goremListFilter: any;
  public dataChange: any;
  public removeItems: any = [];
  public startEdit:boolean = false;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(
    private route: ActivatedRoute,
    public restApi: RestApiService,
    private readonly title: Title,
    private router: Router,
    public dialog: MatDialog,
    private _snackBar: MatSnackBar
  ) {}

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  ngOnInit(){
    this.url_id = this.route.snapshot.paramMap.get('id');
    this.url_gorem = this.route.snapshot.paramMap.get('gorem');
    this.title.setTitle("סדר חותמים באירוע "+this.url_id);
    if(this.url_gorem){
      this.getEvent();
    }else{
      this.getGorems();
    }
    
  }

  getGorems(){
    this.restApi.getGorems(this.url_id).subscribe((data: any) => {
      if(data.success){
        this.goremList = data.data;
        this.goremListFilter = data.data;
      }else{
        this.openSnackBar(data.message);
      }
    });
  }

  goEvent(){
    this.router.navigate(['/event', this.url_id, this.goremSelect]);
  }

  getEvent(){
    this.restApi.getEvent(this.url_id, this.url_gorem).subscribe((data) => {
      if(data.success){
        this.dataChange = data.data;
        this.dataSource.data = data.data;
      }else{
        this.openSnackBar(data.message);
      }
    });
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  goBack(){
    if(this.url_gorem){
      this.router.navigate(['/event', this.url_id]);
    }else{
      this.router.navigate(['/events']);
    }
  }

  onKey(value) { 
    this.goremListFilter = this.search(value);
  }
  
  search(value: string) { 
    let filter = value.toLowerCase();
    return this.goremList.filter(option => option['VSGORM'].toLowerCase().startsWith(filter));
  }

  getUsers(tfkd:any){
    this.restApi.getUsers(tfkd).subscribe((data: any) => {
      const dialogRef = this.dialog.open(EventUsersDialog, {
        width: '650px',
        data: {
          users: data.data
        }
      });
    });
  }

  deleteRow(id){
    this.startEdit = true;
    let arrindex = this.dataChange.findIndex(x => x['VSTFKD'] == id);
    this.removeItems.push({id: id});
    this.dataChange.splice(arrindex, 1);
    //reorder
    let start_index = arrindex;
    let end_index = this.dataChange.length;
    for (let i = start_index; i < end_index; i++) {
      this.dataChange[i].VSSEHA = this.decrementString(this.dataChange[i].VSSEHA);
    }
    this.dataSource.data = this.dataChange;
  }

  SortRow(index:any, position:any){
    this.startEdit = true;
    if(position == 'up'){
      this.dataChange[index].VSSEHA = this.decrementString(this.dataChange[index].VSSEHA);
      this.dataChange[index-1].VSSEHA = this.incrementString(this.dataChange[index-1].VSSEHA);
    }
    if(position == 'down'){
      this.dataChange[index].VSSEHA = this.incrementString(this.dataChange[index].VSSEHA);
      this.dataChange[index+1].VSSEHA = this.decrementString(this.dataChange[index+1].VSSEHA);
    }
    this.dataChange.sort((a:any, b:any) => a.VSSEHA - b.VSSEHA)
    this.dataSource.data = this.dataChange;
  }

  incrementString(str:any) {
    var count = str.match(/\d*$/);
    return str.substr(0, count.index) + (++count[0]);
  };

  decrementString(str:any) {
    var count = str.match(/\d*$/);
    return str.substr(0, count.index) + (--count[0]);
  };

  openSnackBar(message: string) {
    this._snackBar.open(message, 'סגירה');
  }

  unsaveDetails(){
    this.getEvent();
    this.startEdit = false;
  }

  saveDetails(){
    console.log(this.dataChange);
    console.log(this.removeItems);
    let sendArr = {
      orders: this.dataChange,
      removed: this.removeItems,
    }
    this.restApi.updateEvent(sendArr).subscribe((data: any) => {
      this.openSnackBar(data.message);
    });

  }
}

@Component({
  selector: 'event-users-dialog',
  templateUrl: 'event-users.html',
})
export class EventUsersDialog {
  constructor(@Inject(MAT_DIALOG_DATA) public data:any) {}
}
