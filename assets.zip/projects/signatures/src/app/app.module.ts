import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { Routes, RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { LayoutModule } from 'layout';
import { HttpClientModule  } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
//components
import { EventsComponent } from './events/events.component';
import { EventsEditDialog } from './events/events.component';
import { EventComponent } from './event/event.component';
import { EventUsersDialog } from './event/event.component';
//angular material
import {MatTableModule} from '@angular/material/table';
import {MatPaginatorModule} from '@angular/material/paginator';
import {MatSortModule} from '@angular/material/sort';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatInputModule} from '@angular/material/input';
import {MatDialogModule} from '@angular/material/dialog';
import {MatSelectModule} from '@angular/material/select';
import {MatSnackBarModule} from '@angular/material/snack-bar';
import {MatButtonModule} from '@angular/material/button';

const routes: Routes =[
  {
    path: '',
    redirectTo: 'events',
    pathMatch: 'full',
  }, {
    path: 'events',
    component: EventsComponent,
    title: 'ניהול אירועי חתימות'
  }, {
    path: 'event/:id',
    component: EventComponent,
    // title: 'ניהול אירוע:'
  }, {
    path: 'event/:id/:gorem',
    component: EventComponent,
    // title: 'ניהול אירוע:'
  }
];

@NgModule({
  declarations: [
    AppComponent,
    EventsComponent,
    EventsEditDialog,
    EventComponent,
    EventUsersDialog,
  ],
  imports: [
    BrowserModule,
    RouterModule,
    RouterModule.forRoot(routes),
    HttpClientModule,
    BrowserAnimationsModule,
    LayoutModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatProgressSpinnerModule,
    MatFormFieldModule,
    MatInputModule,
    MatDialogModule,
    MatSelectModule,
    MatSnackBarModule,
    MatButtonModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
