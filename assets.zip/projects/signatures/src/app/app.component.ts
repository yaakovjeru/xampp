import {Component, ViewChild, AfterViewInit} from '@angular/core';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort, SortDirection} from '@angular/material/sort';
import {merge, Observable, of as observableOf} from 'rxjs';
import {catchError, map, startWith, switchMap} from 'rxjs/operators';
import {MatTableDataSource} from '@angular/material/table';
import {MatDialog} from '@angular/material/dialog';
import {RestApiService} from './api.service';
import { LayoutService } from 'layout';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  // styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'signatures';
  displayedColumns: string[] = ['VECODE', 'VENAME', 'type', 'buttons'];
  dataSource = new MatTableDataSource();
  resultsLength = 0;
  isLoadingResults = true;
  isRateLimitReached = false;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(
    public dialog: MatDialog,
    public restApi: RestApiService,
    public layout: LayoutService,
  ) { 
    console.log('999');
    // console.log(this.layout.getData());
  }

  ngOnInit(){
    this.getEvents();
  }

  getEvents(){
    this.restApi.getEvents('', '', 0).subscribe((data: any) => {
      if(data.success){
        this.isLoadingResults = false;
        this.dataSource.data = data.data;
      }else{
        // this.openSnackBar(data.message);
      }
    });
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  openDialog() {
    const dialogRef = this.dialog.open(EventsEditDialog);
    dialogRef.afterClosed().subscribe(result => {
      console.log(`Dialog result: ${result}`);
    });
  }
}


@Component({
  selector: 'events-edit-dialog',
  templateUrl: './edit-dialog.html',
})
export class EventsEditDialog {}